import pandas as pd
import os
import numpy as np

# Define your directories
input_directory = 'lieux_final'  # Update this with your input directory path
output_directory = 'lieux_finalModified'  # Update this with your output directory path

# Ensure the output directory exists
if not os.path.exists(output_directory):
    os.makedirs(output_directory)

# Mapping definitions for each column
column_mappings = {
    'catr': {
		'0' : 'autre',
        '1': 'Autoroute',
        '2': 'Route nationale',
        '3': 'Route Départementale',
        '4': 'Voie Communales',
        '5': 'Hors réseau public',
        '6': 'Parc de stationnement ouvert à la circulation publique',
        '7': 'Routes de métropole urbaine',
        '9': 'autre',
		'9.0': 'autre',
        '-1': 'Non renseigne',  # Assuming -1 is used for not provided
    },
    'circ': {
        '1': 'A sens unique',
		'0' : 'autre',
		'0.0' : 'autre',
        '2': 'Bidirectionnelle',
        '3': 'A chaussées séparées',
        '4': 'Avec voies d’affectation variable',
        '-1': 'Non renseigne',
    },
    'vosp': {
        '0': 'Sans objet',
		'0.0': 'Sans objet',
        '1': 'Piste cyclable',
        '2': 'Bande cyclable',
        '3': 'Voie réservée',
        '-1': 'Non renseigne',
    },
	'prof' : {
		'-1' : 'Non renseigne',
		'0' : 'autre',
		'0.0' : 'autre',
		'1' : 'Plat',
		'2' : 'Pente',
		'3' : 'Sommet de côte',
		'4' : 'Bas de côte',
	},
	'plan' : {
		'-1' : 'Non renseigne',
		'0' : 'Non renseigne',
		'0.0' : 'Non renseigne',
		'1' : 'Partie rectiligne',
		'2':  'En courbe à gauche',
		'3' : 'En courbe à droite',
		'4' : 'En « S »',
	},
	'surf' : {
		'-1':  'Non renseigne',
		'0' : 'Non renseigne',
		'0.0' : 'Non renseigne',
		'1' : 'Normale',
		'2' : 'Mouillée',
		'3' : 'Flaques',
		'4' : 'Inondée',
		'5' : 'Enneigée',
		'6' : 'Boue',
		'7' : 'Verglacée',
		'8' : 'Corps gras – huile',
		'9' : 'Autre',
	},
	'infra' : {
		'-1' :'Non renseigne',
		'0' :'Aucun',
		'0.0' : 'Aucun',
		'1' :'Souterrain - tunnel',
		'2' :'Pont - autopont',
		'3' :'Bretelle d’échangeur ou de raccordement',
		'4' :'Voie ferrée',
		'5' :'Carrefour aménagé',
		'6' :'Zone piétonne',
		'7' :'Zone de péage',
		'8' :'Chantier',
		'9' :'Autres',
	},
	'situ' : {
		'-1' : 'Non renseigne',
		'0' :'Aucun',
		'0.0' : 'Aucun',
		'1' :'Sur chaussée',
		'2' :'Sur bande d’arrêt d’urgence',
		'3' :'Sur accotement',
		'4' :'Sur trottoir',
		'5' :'Sur piste cyclable',
		'6' :'Sur autre voie spéciale',
		'8' :'Autres',
	},
}

def apply_mappings(df, mappings):
    for column, mapping in mappings.items():
        # Check if the column exists to avoid KeyError
        if column in df:
            # Apply mapping, use df[column].map(mapping) if all values are expected to be in the mapping
            df[column] = df[column].apply(lambda x: mapping.get(str(x), x))
    return df

# Process each file in the input directory
for filename in os.listdir(input_directory):
    if filename.endswith(".xlsx") and 'final' in filename:
        file_path = os.path.join(input_directory, filename)
        df = pd.read_excel(file_path)

        # Apply mappings
        df = apply_mappings(df, column_mappings)

        # Construct the new filename and path for output
        new_filename = filename.replace('final', 'finalModified')
        output_path = os.path.join(output_directory, new_filename)

        # Save the updated DataFrame
        df.to_excel(output_path, index=False, engine='openpyxl')

        print(f"Processed and saved {new_filename} in {output_directory}")
