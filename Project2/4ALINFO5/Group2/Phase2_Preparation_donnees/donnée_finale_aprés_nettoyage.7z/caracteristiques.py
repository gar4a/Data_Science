import pandas as pd
import numpy as np
import os
import openpyxl

# Function to process each CSV file
def process_csv(file_path):
    # Load the CSV file
    df = pd.read_csv(file_path)

    # Preprocessing for 'hrmn' to ensure it's in a proper 4-digit format
    df["hrmn"] = df["hrmn"].astype(str).str.zfill(4)

    df["mois"] = df["mois"].astype(str).str.zfill(2)
    df["jour"] = df["jour"].astype(str).str.zfill(2)
    df["hour"] = df["hrmn"].str[:2]  # Extract hour
    df["minute"] = df["hrmn"].str[-2:]  # Extract minute


    df['an'] = df['an'].apply(lambda x: (2000 + int(x)) if len(str(x)) != 4 else int(x))
    df['an'] = df['an'].astype(str)

    # Create 'Date' column by combining the year, month, day, hour, and minute
    df["Date"] = pd.to_datetime(
        df["an"]
        + "-"
        + df["mois"]
        + "-"
        + df["jour"]
        + " "
        + df["hour"]
        + ":"
        + df["minute"]
    )

    # Replace empty values with 0 in 'lat' and 'long', ensure numeric type
    df["lat"] = pd.to_numeric(df["lat"], errors="coerce").fillna(0)
    # Convert latitude to degrees
    df["lat"] = df["lat"] / 111319.9
    df["long"] = pd.to_numeric(df["long"], errors="coerce").fillna(0)
    df["long"] = df.apply(
        lambda row: row["long"]
        / (111319.9 * abs(np.cos(np.radians(row["lat"] / 1000000)))),
        axis=1,
    )

    # Replace empty values with 'M' in 'gps' if it exists else, create a column  with 'M' as value
    df['gps'] = 'M' if 'gps' not in df.columns else df["gps"].fillna("M")

    # Remove the specified columns
    columns_to_drop = ["an", "mois", "jour", "hrmn", "hour", "minute"]
    df.drop(columns=columns_to_drop, inplace=True)

    # Extract base name (without extension) to use as the output file name
    file_name = os.path.splitext(os.path.basename(file_path))[0]
    file_name = file_name.replace(file_name.split("_")[2], "final")

    # Specify the output XLSX file with the modified file_name
    xlsx_file = os.path.join(
        output_dir, f"{file_name}.xlsx"
    )  # Output file will have the modified file_name

    # Save to xlsx
    df.to_excel(
        xlsx_file, index=False, engine="openpyxl"
    )  # Export DataFrame to XLSX without the index

    print(f"File {file_path} has been processed and saved as {xlsx_file}")


# Directory paths
input_dir = "caracteristiques"
output_dir = "caracteristiques_final"

# Create output directory if not exists
os.makedirs(output_dir, exist_ok=True)

# Process each CSV file in the input directory
for file_name in os.listdir(input_dir):
    if file_name.endswith(".csv"):
        file_path = os.path.join(input_dir, file_name)
        process_csv(file_path)

print("All files have been processed.")
