import pandas as pd
import os
import numpy as np

# Define your directories
input_directory = 'vehicules_final'  # Update this with your input directory path
output_directory = 'vehicules_finalModified'  # Update this with your output directory path

# Ensure the output directory exists
if not os.path.exists(output_directory):
    os.makedirs(output_directory)

# Mapping definitions for each column
column_mappings = {
    'senc': {
		'-1' : 'Non renseigne',
		'0' : 'Inconnu',
		'0.0' : 'Inconnu',
        '1': 'PK ou PR ou numéro d’adresse postale croissant',
        '2': '– PK ou PR ou numéro d’adresse postale décroissant',
        '3': 'Absence de repère',
    },
	'catv' : {
		'-1' : 'Non renseigne',
		'0' : 'Non renseigne',
		'00': 'Indéterminable',
		'01': 'Bicyclette',
		'02': 'Cyclomoteur <50cm3',
		'03': 'Voiturette (Quadricycle à moteur carrossé)',
		'04': 'Référence inutilisée depuis 2006 (scooter immatriculé)',
		'05': 'Référence inutilisée depuis 2006 (motocyclette)',
		'06': 'Référence inutilisée depuis 2006 (side-car)',
		'07': 'VL seul',
		'08': 'Référence inutilisée depuis 2006 (VL + caravane)',
		'09': 'Référence inutilisée depuis 2006 (VL + remorque)',
		'10': 'VU seul 1,5T <= PTAC <= 3,5T avec ou sans remorque',
		'11': 'Référence inutilisée depuis 2006 (VU + caravane)',
		'12': 'Référence inutilisée depuis 2006 (VU + remorque)',
		'13': 'PL seul 3,5T <PTCA <= 7,5T',
		'14': 'PL seul > 7,5T',
		'15': 'PL > 3,5T + remorque',
		'16': 'Tracteur routier seul',
		'17': 'Tracteur routier + semi-remorque',
		'18': 'Référence inutilisée depuis 2006 (transport en commun)',
		'19': 'Référence inutilisée depuis 2006 (tramway)',
		'20': 'Engin spécial',
		'21': 'Tracteur agricole',
		'30': 'Scooter < 50 cm3',
		'31': 'Motocyclette > 50 cm3 et <= 125 cm3',
		'32': 'Scooter > 50 cm3 et <= 125 cm3',
		'33': 'Motocyclette > 125 cm3',
		'34': 'Scooter > 125 cm3',
		'35': 'Quad léger <= 50 cm3',
		'36': 'Quad lourd > 50 cm3',
		'37': 'Autobus',
		'38': 'Autocar',
		'39': 'Train',
		'40': 'Tramway',
		'41': '3RM <= 50 cm3',
		'42': '3RM > 50 cm3 <= 125 cm3',
		'43': '3RM > 125 cm3',
		'50': 'EDP à moteur',
		'60': 'EDP sans moteur',
		'80': 'VAE',
		'99': 'Autre véhicule',
	},
    'obs' : {
		'-1': 'Non renseigné',
		'0': 'Sans objet',
		'0.0': 'Sans objet',
		'1': 'Véhicule en stationnement',
		'2': 'Arbre',
		'3': 'Glissière métallique',
		'4': 'Glissière béton',
		'5': 'Autre glissière',
		'6': 'Bâtiment, mur, pile de pont',
		'7': 'Support de signalisation verticale ou poste d’appel d’urgence',
		'8': 'Poteau',
		'9': 'Mobilier urbain',
		'10': 'Parapet',
		'11': 'Ilot, refuge, borne haute',
		'12': 'Bordure de trottoir',
		'13': 'Fossé, talus, paroi rocheuse',
		'14': 'Autre obstacle fixe sur chaussée',
		'15': 'Autre obstacle fixe sur trottoir ou accotement',
		'16': 'Sortie de chaussée sans obstacle',
		'17': 'Buse – tête d’aqueduc',
	},
	'obsm' : {
		'-1' : 'Non renseigne',
		'0' : 'Aucun',
		'0.0' : 'Aucun',
		'1' : 'Piéton',
		'2' : 'Véhicule',
		'4' : 'Véhicule sur rail ',
		'5' : 'Animal domestique',
		'6' : 'Animal sauvage',
		'9' : 'Autre',
		'9.0' : 'Autre',
	},
	'choc' : {
		'-1' : 'Non renseigne',
		'0' : 'Aucun',
		'0.0' : 'Aucun',
		'1' : 'Avant',
		'2':  'Avant droit',
		'3' : 'Avant gauche',
		'4' : 'Arrière',
		'5' : 'Arrière droit',
		'6' :'Arrière gauche',
		'7' :'Côté droit',
		'8' :'Côté gauche',
		'9' :'Chocs multiples (tonneaux)',
	},
	'manv' : {
		'-1': 'Non renseigné',
		'0': 'Inconnue',
		'0.0': 'Inconnue',
		'1': 'Sans changement de direction',
		'2': 'Même sens, même file',
		'3': 'Entre 2 files',
		'4': 'En marche arrière',
		'5': 'A contresens',
		'6': 'En franchissant le terre-plein central',
		'7': 'Dans le couloir bus, dans le même sens',
		'8': 'Dans le couloir bus, dans le sens inverse',
		'9': 'En s’insérant',
		'10': 'En faisant demi-tour sur la chaussée',
		'11': 'Changeant de file à gauche',
		'12': 'Changeant de file à droite',
		'13': 'Déporté à gauche',
		'14': 'Déporté à droite',
		'15': 'Tournant à gauche',
		'16': 'Tournant à droite',
		'17': 'Dépassant à gauche',
		'18': 'Dépassant à droite',
		'19': 'Traversant la chaussée',
		'20': 'Manœuvre de stationnement',
		'21': 'Manœuvre d’évitement',
		'22': 'Ouverture de porte',
		'23': 'Arrêté (hors stationnement)',
		'24': 'En stationnement (avec occupants)',
		'25': 'Circulant sur trottoir',
		'26': 'Autres manœuvres',
	},
	'motor' : {
		'-1' : 'Non renseigne',
		'0' : 'Inconnue',
		'0.0' : 'Inconnue',
		'1' : 'Hydrocarbures',
		'2':  'Hybride électrique',
		'3' : 'Electrique',
		'4' : 'Hydrogène',
		'5' : 'Humaine',
		'6' :'Autre',
	},
}

def apply_mappings(df, mappings):
    for column, mapping in mappings.items():
        # Check if the column exists to avoid KeyError
        if column in df:
            # Apply mapping, use df[column].map(mapping) if all values are expected to be in the mapping
            df[column] = df[column].apply(lambda x: mapping.get(str(x), x))
    return df

# Process each file in the input directory
for filename in os.listdir(input_directory):
    if filename.endswith(".xlsx") and 'final' in filename:
        file_path = os.path.join(input_directory, filename)
        df = pd.read_excel(file_path)

        # Apply mappings
        df = apply_mappings(df, column_mappings)

        # Construct the new filename and path for output
        new_filename = filename.replace('final', 'finalModified')
        output_path = os.path.join(output_directory, new_filename)

        # Save the updated DataFrame
        df.to_excel(output_path, index=False, engine='openpyxl')

        print(f"Processed and saved {new_filename} in {output_directory}")
