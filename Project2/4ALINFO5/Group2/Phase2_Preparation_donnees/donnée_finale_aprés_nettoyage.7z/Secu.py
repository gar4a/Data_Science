import pandas as pd
import os

# Define your directories
input_directory = 'usagers_final'  # Update this with your input directory path
output_directory = 'usagers_finalModified'  # Update this with your output directory path

# Ensure the output directory exists
if not os.path.exists(output_directory):
    os.makedirs(output_directory)

# Mapping definitions for each column
mapping = {
    '-1': 'Non renseigne',
    '0': 'Aucun équipement',
    '0': 'Non renseigne',
    '1': 'Ceinture',
    '2': 'Casque',
    '3': 'Dispositif enfants',
    '10': 'Ceinture',
    '11': 'Ceinture',
    '12': 'Ceinture',
    '13': 'Ceinture',
    '20': 'Casque',
    '21': 'Casque',
    '22': 'Casque',
    '23': 'Casque',
    '30': 'Dispositif enfants',
    '31': 'Dispositif enfants',
    '32': 'Dispositif enfants',
    '33': 'Dispositif enfants',
    '40': 'Gilet réfléchissant',
    '41': 'Gilet réfléchissant',
    '42': 'Gilet réfléchissant',
    '43': 'Gilet réfléchissant',
    '90': 'Autre',
    '91': 'Autre',
    '92': 'Autre',
    '93': 'Autre',
    '5': 'Airbag (2RM/3RM)',
    '6': 'Gants (2RM/3RM)',
    '7': 'Gants + Airbag (2RM/3RM)',
    '8': 'Non déterminable',
    '9': 'Autre',
}

def map_values(key):
    return mapping.get(key, key)

# Process each file in the input directory
for filename in os.listdir(input_directory):
    if filename.endswith(".xlsx") and 'final' in filename:
        file_path = os.path.join(input_directory, filename)
        df = pd.read_excel(file_path,dtype={'secu':str})

        # Apply mappings
        print("Before mapping:")
        print(df['secu'])

        df['secu'] = df['secu'].astype(str)
        df['secu'] = df['secu'].apply(map_values)

        print("After mapping:")
        print(df['secu'])

        # Construct the new filename and path for output
        new_filename = filename.replace('final', 'finalModified')
        output_path = os.path.join(output_directory, new_filename)

        # Save the updated DataFrame
        df.to_excel(output_path, index=False, engine='openpyxl')

        print(f"Processed and saved {new_filename} in {output_directory}")
