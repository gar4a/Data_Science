import pandas as pd
import os
import numpy as np

# Define your directories
input_directory = 'caracteristiques_final'  # Update this with your input directory path
output_directory = 'caracteristiques_finalModified'  # Update this with your output directory path

# Ensure the output directory exists
if not os.path.exists(output_directory):
    os.makedirs(output_directory)

# Mapping definitions for each column
column_mappings = {
    'lum': {
		'-1' : 'Non renseigne',
		'0' : 'autre',
        '1': 'Plein jour',
        '2': 'Crépuscule ou aube',
        '3': 'Nuit sans éclairage public',
        '4': 'Nuit avec éclairage public non allumé',
        '5': 'Nuit avec éclairage public allumé',
    },
    'int': {
		'-1' : 'Non renseigne',
        '1': 'Hors intersection',
		'0' : 'autre',
        '2': 'Intersection en X',
        '3': 'Intersection en T',
        '4': 'Intersection en Y',
        '5': 'Intersection à plus de 4 branches',
        '6': 'Giratoire',
        '7': 'Place',
        '8': 'Passage à niveau',
        '9': 'Autre intersection',
    },
    'atm': {
		'-1' : 'Non renseigne',
        '0': 'Sans objet',
        '1': 'Normale',
        '2': 'Pluie légère',
        '3': 'Pluie forte',
        '4': 'Neige - grêle',
        '5': 'Brouillard - fumée',
        '6': 'Vent fort - tempête',
        '7': 'Temps éblouissant',
        '8': 'Temps couvert',
		'9':  'Autre',
    },
	'prof' : {
		'-1' : 'Non renseigne',
		'0' : 'autre',
		'1' : 'Plat',
		'2' : 'Pente',
		'3' : 'Sommet de côte',
		'4' : 'Bas de côte',
	},
	'plan' : {
		'-1' : 'Non renseigne',
		'0' : 'Non renseigne',
		'0.0' : 'Non renseigne',
		'1' : 'Partie rectiligne',
		'2':  'En courbe à gauche',
		'3' : 'En courbe à droite',
		'4' : 'En « S »',
	},
	'col' : {
		'-1':  'Non renseigne',
		'0' : 'Non renseigne',
		'0.0' : 'Non renseigne',
		'1' : 'Deux véhicules - frontale',
		'2' : 'Deux véhicules – par l’arrière ',
		'3' : 'Deux véhicules – par le coté',
		'4' : 'Trois véhicules et plus – en chaîne',
		'5' : 'Trois véhicules et plus - collisions multiples',
		'6' : 'Autre collision',
		'7' : 'Sans collision',
		'9' : 'Autre',
	},
}

def apply_mappings(df, mappings):
    for column, mapping in mappings.items():
        # Check if the column exists to avoid KeyError
        if column in df:
            # Apply mapping, use df[column].map(mapping) if all values are expected to be in the mapping
            df[column] = df[column].apply(lambda x: mapping.get(str(x), x))
    return df

# Process each file in the input directory
for filename in os.listdir(input_directory):
    if filename.endswith(".xlsx") and 'final' in filename:
        file_path = os.path.join(input_directory, filename)
        df = pd.read_excel(file_path)

        # Apply mappings
        df = apply_mappings(df, column_mappings)

        # Construct the new filename and path for output
        new_filename = filename.replace('final', 'finalModified')
        output_path = os.path.join(output_directory, new_filename)

        # Save the updated DataFrame
        df.to_excel(output_path, index=False, engine='openpyxl')

        print(f"Processed and saved {new_filename} in {output_directory}")
