import pandas as pd
import os
import numpy as np

# Define your directories
input_directory = 'usagers_final'  # Update this with your input directory path
output_directory = 'usagers_finalModified'  # Update this with your output directory path

# Ensure the output directory exists
if not os.path.exists(output_directory):
    os.makedirs(output_directory)

# Mapping definitions for each column
column_mappings = {
    'catu': {
		'0' : 'autre',
        '1': 'Conducteur',
        '2': 'Passager',
        '3': 'Piéton',
        '4': 'Autre',
    },
    'grav': {
		'-1' : 'Non renseigne',
		'0' : 'autre',
        '1': 'Indemne',
        '2': 'Tué',
        '3': 'Blessé hospitalisé',
        '4': 'Blessé léger',
    },
    'sexe': {
		'-1' : 'Non renseigne',
        '0': 'Sans objet',
        '1': 'Masculin',
        '2': 'Féminin',
    },
	'trajet' : {
		'-1' : 'Non renseigne',
		'0' : 'Non renseigne',
		'0.0' : 'Non renseigne',
		'1' : 'Domicile – travail',
		'2' : 'Domicile – école',
		'3' : 'Courses – achats',
		'4' : 'Utilisation professionnelle',
		'5' : 'Promenade – loisirs',
		'9' : 'Autre',
		'9.0' : 'Autre',
	},
	'secu' : {
		'-1': 'Non renseigne',
		'0': 'Aucun équipement',
		'0.0': 'Non renseigne',
		'1': 'Ceinture',
		'2': 'Casque',
		'3': 'Dispositif enfants',
		'10': 'Ceinture',
		'11': 'Ceinture',
		'12': 'Ceinture',
		'13': 'Ceinture',
		'20': 'Casque',
		'21': 'Casque',
		'22': 'Casque',
		'23': 'Casque',
		'30': 'Dispositif enfants',
		'31': 'Dispositif enfants',
		'32': 'Dispositif enfants',
		'33': 'Dispositif enfants',
		'40': 'Gilet réfléchissant',
		'41': 'Gilet réfléchissant',
		'42': 'Gilet réfléchissant',
		'43': 'Gilet réfléchissant',
		'90': 'Autre',
		'91': 'Autre',
		'92': 'Autre',
		'93': 'Autre',
		'5': 'Airbag (2RM/3RM)',
		'6': 'Gants (2RM/3RM)',
		'7': 'Gants + Airbag (2RM/3RM)',
		'8': 'Non déterminable',
		'9': 'Autre',
	},
	'secu1' : {
		'-1' : 'Non renseigne',
		'0' : 'Aucun équipement',
		'0.0' : 'Non renseigne',
		'1' : 'Ceinture',
		'2':  'Casque',
		'3' : 'Dispositif enfants',
		'4' : 'Gilet réfléchissant',
		'5' : 'Airbag (2RM/3RM) ',
		'6' :'Gants (2RM/3RM)',
		'7' :'Gants + Airbag (2RM/3RM)',
		'8' :'Non déterminable',
		'9' :'Autre',
	},
	'secu2' : {
		'-1' : 'Non renseigne',
		'0' : 'Aucun équipement',
		'0.0' : 'Non renseigne',
		'1' : 'Ceinture',
		'2':  'Casque',
		'3' : 'Dispositif enfants ',
		'4' : 'Gilet réfléchissant',
		'5' : 'Airbag (2RM/3RM) ',
		'6' :'Gants (2RM/3RM)',
		'7' :'Gants + Airbag (2RM/3RM)',
		'8' :'Non déterminable',
		'9' :'Autre',
	},
	'secu3' : {
		'-1' : 'Non renseigne',
		'0' : 'Aucun équipement',
		'0.0' : 'Non renseigne',
		'1' : 'Ceinture',
		'2':  'Casque',
		'3' : 'Dispositif enfants ',
		'4' : 'Gilet réfléchissant',
		'5' : 'Airbag (2RM/3RM) ',
		'6' :'Gants (2RM/3RM)',
		'7' :'Gants + Airbag (2RM/3RM)',
		'8' :'Non déterminable',
		'9' :'Autre',
	},
	'locp' : {
		'-1':  'Non renseigne',
		'0' : 'Sans objet',
		'0.0' : 'Non renseigne',
		'1' : 'A + 50 m du passage piéton',
		'2' : 'A – 50 m du passage piéton',
		'3' : 'Sans signalisation lumineuse',
		'4' : 'Avec signalisation lumineuse',
		'5' : 'Sur trottoir',
		'6' : 'Sur accotement',
		'7' : 'Sur refuge ou BAU',
		'8' : 'Sur contre allée',
		'9' : 'Inconnue',
	},
	'actp' : {
		'-1':  'Non renseigne',
		'0' : 'Non renseigné ou sans objet',
		'0.0' : 'Non renseigné ou sans objet',
		'1' : 'Sens véhicule heurtant',
		'2' : 'Sens inverse du véhicule',
		'3' : 'Traversant',
		'4' : 'Masqué',
		'5' : 'Jouant – courant ',
		'6' : 'Avec animal',
		'A' : 'Monte/descend du véhicule',
		'B' : 'Inconnue',
		'9' : 'Autre',
	},
	'etatp' : {
		'-1':  'Non renseigne',
		'0' : 'Non renseigné ou sans objet',
		'0.0' : 'Non renseigné ou sans objet',
		'1' : 'Seul',
		'2' : 'Accompagné',
		'3' : 'En groupe',
	},
}

def apply_mappings(df, mappings):
    for column, mapping in mappings.items():
        # Check if the column exists to avoid KeyError
        if column in df:
            # Apply mapping, use df[column].map(mapping) if all values are expected to be in the mapping
            df[column] = df[column].apply(lambda x: mapping.get(str(x), x))
    return df

# Process each file in the input directory
for filename in os.listdir(input_directory):
    if filename.endswith(".xlsx") and 'final' in filename:
        file_path = os.path.join(input_directory, filename)
        df = pd.read_excel(file_path,dtype={'secu':str})

        # Apply mappings
        df = apply_mappings(df, column_mappings)

        # Construct the new filename and path for output
        new_filename = filename.replace('final', 'finalModified')
        output_path = os.path.join(output_directory, new_filename)

        # Save the updated DataFrame
        df.to_excel(output_path, index=False, engine='openpyxl')

        print(f"Processed and saved {new_filename} in {output_directory}")
