import pandas as pd
import numpy as np
import os
import openpyxl

# Function to process each CSV file
def process_csv(file_path):
    # Load the CSV file
    df = pd.read_csv(file_path)

    # Extract base name (without extension) to use as the output file name
    file_name = os.path.splitext(os.path.basename(file_path))[0]
    file_name = file_name.replace(file_name.split("_")[2], "final")

    # Specify the output XLSX file with the modified file_name
    xlsx_file = os.path.join(
        output_dir, f"{file_name}.xlsx"
    )  # Output file will have the modified file_name

    # Save to xlsx
    df.to_excel(
        xlsx_file, index=False, engine="openpyxl"
    )  # Export DataFrame to XLSX without the index

    print(f"File {file_path} has been processed and saved as {xlsx_file}")


# Directory paths
input_dir = "vehicules"
output_dir = "vehicules_final"

# Create output directory if not exists
os.makedirs(output_dir, exist_ok=True)

# Process each CSV file in the input directory
for file_name in os.listdir(input_dir):
    if file_name.endswith(".csv"):
        file_path = os.path.join(input_dir, file_name)
        process_csv(file_path)

print("All files have been processed.")
