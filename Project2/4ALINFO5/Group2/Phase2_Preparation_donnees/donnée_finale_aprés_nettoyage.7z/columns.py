import os
import pandas as pd

# Directory containing the Excel files
directory = 'usagers_finalModified'

# Output text file path
output_file_path = os.path.join(directory, os.path.basename(directory) + '_columns.txt')

# Set to store unique columns
unique_columns = set()

# Open the output file in write mode
with open(output_file_path, 'w') as output_file:
    # Iterate over each file in the directory
    for filename in os.listdir(directory):
        if filename.endswith('.xlsx'):
            # Read the Excel file
            file_path = os.path.join(directory, filename)
            df = pd.read_excel(file_path)
            
            # Write the file name to the output file
            output_file.write(f"Columns in {filename}:\n")
            
            # Write the column names to the output file
            if len(unique_columns) == 0:
                for column in df.columns:
                    output_file.write(f"{column}\n")
                    unique_columns.add(column)
            else:
                new_columns = set(df.columns) - unique_columns
                for column in new_columns:
                    output_file.write(f"{column}\n")
                    unique_columns.add(column)
            
            # Write total number of columns
            output_file.write(f"Total number of columns: {len(df.columns)}\n")
            
            # Write a separator for clarity
            output_file.write("-" * 50 + "\n")
